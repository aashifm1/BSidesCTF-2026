(defproject book-library "0.1.0-SNAPSHOT"
  :description "A CLI book library application"
  :dependencies [[org.clojure/clojure "1.11.1"]
                [org.clojure/data.json "2.4.0"]]
  :main book-library.core
  :aot [book-library.core])