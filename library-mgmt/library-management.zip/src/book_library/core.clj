(ns book-library.core
  (:gen-class))

(def library-db (atom []))

(defn valid-book? [book]
  (and (map? book)
       (string? (:title book))
       (string? (:author book))))

(defn parse-book-data [book-string]
  (try 
    (if (and (string? book-string)
             (.contains book-string ":title")
             (.contains book-string ":author"))
      (let [data (read-string book-string)]
        (if (valid-book? data)
          data
          nil))
      nil)
    (catch Exception e
      (println "Error parsing book data:" (.getMessage e))
      nil)))

(defn add-book [book-data]
  (if-let [parsed-data (parse-book-data book-data)]
    (do
      (swap! library-db conj 
             (assoc parsed-data 
                    :id (count @library-db)
                    :available true))
      true)
    false))

(defn remove-book [id]
  (let [id-num (try (Integer/parseInt id)
                    (catch Exception _ -1))]
    (swap! library-db 
           (fn [books]
             (vec (remove #(= (:id %) id-num) books))))))

(defn list-books []
  (if (empty? @library-db)
    (println "No books in the library.")
    (doseq [book @library-db]
      (println (str "ID: " (:id book)
                   " | Title: " (:title book)
                   " | Author: " (:author book)
                   " | Available: " (:available book))))))

(defn borrow-book [id]
  (let [id-num (try (Integer/parseInt id)
                    (catch Exception _ -1))]
    (swap! library-db
           (fn [books]
             (mapv #(if (= (:id %) id-num)
                     (assoc % :available false)
                     %)
                   books)))))

(defn return-book [id]
  (let [id-num (try (Integer/parseInt id)
                    (catch Exception _ -1))]
    (swap! library-db
           (fn [books]
             (mapv #(if (= (:id %) id-num)
                     (assoc % :available true)
                     %)
                   books)))))

(defn print-menu []
  (println "\nLibrary Management System")
  (println "1. Add book")
  (println "2. Remove book")
  (println "3. List all books")
  (println "4. Borrow book")
  (println "5. Return book")
  (println "6. Exit")
  (print "\nSelect an option: ")
  (flush))

(defn get-input [prompt]
  (print prompt)
  (flush)
  (read-line))

(defn handle-add-book []
  (println "\nEnter book details in Clojure map format:")
  (println "Example: {:title \"The Hobbit\" :author \"J.R.R. Tolkien\"}")
  (let [book-data (get-input "\nBook data: ")]
    (if (add-book book-data)
      (println "Book added successfully!")
      (println "Error: Invalid book data format. Please use the example format."))))

(defn handle-remove-book []
  (list-books)
  (let [id (get-input "Enter book ID to remove: ")]
    (remove-book id)
    (println "Book removed successfully!")))

(defn handle-borrow-book []
  (list-books)
  (let [id (get-input "Enter book ID to borrow: ")]
    (borrow-book id)
    (println "Book borrowed successfully!")))

(defn handle-return-book []
  (list-books)
  (let [id (get-input "Enter book ID to return: ")]
    (return-book id)
    (println "Book returned successfully!")))

(defn -main []
  (loop []
    (print-menu)
    (let [choice (get-input "")]
      (case choice
        "1" (handle-add-book)
        "2" (handle-remove-book)
        "3" (list-books)
        "4" (handle-borrow-book)
        "5" (handle-return-book)
        "6" (System/exit 0)
        (println "Invalid option! Please try again."))
      (recur))))