#!/bin/bash

echo "[+] Listening on port 1337"
while true; do
    socat -t60 -T60 TCP-LISTEN:1337,reuseaddr,fork SYSTEM:'sh entrypoint.sh'
done
